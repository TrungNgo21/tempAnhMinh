create definer = root@localhost trigger update_warehouse_volume
    after update
    on warehouse_inventory
    for each row
    call common_update_volume(new.warehouseID);

