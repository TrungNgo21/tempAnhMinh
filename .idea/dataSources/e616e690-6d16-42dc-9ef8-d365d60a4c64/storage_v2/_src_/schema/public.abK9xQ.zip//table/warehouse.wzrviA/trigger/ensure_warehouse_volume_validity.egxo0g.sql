create definer = root@localhost trigger ensure_warehouse_volume_validity
    before update
    on warehouse
    for each row
begin
        if NEW.volume < old.fillVolume then
            signal sqlstate '45000' set message_text = 'old volume cant be smaller than filled volume';
        end if;
    end;

