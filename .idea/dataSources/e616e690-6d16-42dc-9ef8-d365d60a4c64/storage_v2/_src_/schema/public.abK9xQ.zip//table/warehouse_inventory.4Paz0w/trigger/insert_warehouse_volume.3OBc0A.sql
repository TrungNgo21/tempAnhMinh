create definer = root@localhost trigger insert_warehouse_volume
    after insert
    on warehouse_inventory
    for each row
    call common_update_volume(new.warehouseID);

