create
    definer = root@localhost procedure product_purchase_order(IN product_id varchar(24), IN qty bigint)
begin
    declare iqty bigint default 0;
    declare pvolume bigint default (select volume from product where id = product_id);
    declare _rollback bool default 0;
    declare continue handler for sqlexception set _rollback = 1;

    start transaction;
    while _rollback = 0 and iqty < qty do
            create temporary table temp select id from warehouse where Volume > (fillVolume + pvolume) group by id;

            if (select count(id) from temp) = 0 then
                set _rollback = 1;
            else
                set iqty = iqty + 1;
                set @wid = (select warehouseID
                            from warehouse_inventory
                            where warehouseID in (
                                select id
                                from (select id from temp) t)
                              and productID = product_id
                            order by quantity, warehouseID
                            limit 1);
                if @wid IS NOT NULL then
                    update warehouse_inventory set quantity = quantity + 1 where productID = product_id and warehouseID = @wid;
                else
                    insert into warehouse_inventory (warehouseID, productID, quantity) value ((select id from temp limit 1), product_id, 1);
                end if;
            end if;
            drop temporary table if exists temp;
        end while;
    if _rollback = 1 then
        rollback;
        select true as err, 'inventory exceed all warehouse capacity' as message;
    else
        commit;
        select false as err, 'PO success' as message;
    end if;
    drop temporary table if exists temp;
end;

grant execute on procedure product_purchase_order to warehouse_staff;

