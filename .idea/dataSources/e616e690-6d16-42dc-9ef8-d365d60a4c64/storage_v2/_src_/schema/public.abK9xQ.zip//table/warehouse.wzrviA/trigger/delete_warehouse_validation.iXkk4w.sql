create definer = root@localhost trigger delete_warehouse_validation
    before delete
    on warehouse
    for each row
begin
    if (select count(warehouseID) from warehouse_inventory where warehouseID = old.id) != 0 then
        signal sqlstate '45000' set message_text = 'warehouse contain inventory';
    end if;
end;

