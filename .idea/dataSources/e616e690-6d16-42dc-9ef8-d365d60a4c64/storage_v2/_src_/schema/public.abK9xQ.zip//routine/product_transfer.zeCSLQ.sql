create
    definer = root@localhost procedure product_transfer(IN product_id varchar(24), IN from_wh bigint, IN to_wh bigint,
                                                        IN qty bigint)
begin
    declare i bigint;
    declare c bool;
    declare _rollback bool default 0;
    declare continue handler for sqlexception set _rollback = 1;

    select count(warehouseID) into i from warehouse_inventory where warehouseID = to_wh and productID = product_id;
    if i != 0 then
        start transaction;
        update warehouse_inventory set quantity = quantity - qty where warehouseID = from_wh and productID = product_id;
        update warehouse_inventory set quantity = quantity + qty where warehouseID = to_wh and productID = product_id;

        select (Volume > fillVolume) into c from warehouse where warehouse.ID = to_wh;

        if !c then
            set _rollback = 1;
        end if;

        if _rollback = 1 then
            rollback;
            select true as err;
        else
            commit;
            select false as err;
        end if;

    else
        start transaction;
        update warehouse_inventory set quantity = quantity - qty where warehouseID = from_wh and productID = product_id;
        if _rollback = 1 then
            rollback;
            select true as err;
        else
            insert into warehouse_inventory (warehouseID, productID, quantity) values (to_wh, product_id, qty);
            commit;
            select false as err;
        end if;
    end if;
end;

grant execute on procedure product_transfer to warehouse_staff;

