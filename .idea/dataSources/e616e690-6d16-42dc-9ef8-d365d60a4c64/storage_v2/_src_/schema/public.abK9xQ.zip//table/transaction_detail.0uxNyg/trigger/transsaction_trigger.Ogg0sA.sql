create definer = root@localhost trigger transsaction_trigger
    after insert
    on transaction_detail
    for each row
begin
        update transaction t
            set t.quantity = t.quantity + new.quantity,
                t.price = t.price + (new.quantity * new.price)
            where t.id = new.transId;
    end;

