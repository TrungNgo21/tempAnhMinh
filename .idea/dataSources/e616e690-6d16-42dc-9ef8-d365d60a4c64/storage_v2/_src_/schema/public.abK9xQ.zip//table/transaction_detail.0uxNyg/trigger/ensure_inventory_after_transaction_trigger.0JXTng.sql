create definer = root@localhost trigger ensure_inventory_after_transaction_trigger
    after insert
    on transaction_detail
    for each row
begin
        declare product_id varchar(255);
        declare warehouse_id int;

        set product_id = new.productId;

        select wi.warehouseID into warehouse_id
        from warehouse_inventory wi
        where wi.productID = product_id
        order by wi.quantity desc limit 1;

        update warehouse_inventory
        set quantity = quantity - new.quantity
        where productID = product_id and warehouseID = warehouse_id;
    end;

