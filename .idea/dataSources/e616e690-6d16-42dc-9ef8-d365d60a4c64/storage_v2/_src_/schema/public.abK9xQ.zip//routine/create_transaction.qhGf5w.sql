create
    definer = root@localhost procedure create_transaction(IN id varchar(255), IN product_data json)
begin
    declare new_bill_id int;
    declare _index int default 0;
    declare num_product int;
    declare _rollback bool default 0;
    declare continue handler for sqlexception set _rollback = 1;

    start transaction ;
    insert into transaction(userId) values (id);

    set new_bill_id = LAST_INSERT_ID();

    set num_product = JSON_LENGTH(product_data);

    while _index < num_product do
        SET @product_id = JSON_UNQUOTE(JSON_EXTRACT(product_data, CONCAT('$[', _index, '].id')));
        SET @quantity = JSON_EXTRACT(JSON_UNQUOTE(JSON_EXTRACT(product_data, CONCAT('$[', _index, '].quantity'))), '$');
        SET @price = JSON_EXTRACT(JSON_UNQUOTE(JSON_EXTRACT(product_data, CONCAT('$[', _index, '].price'))), '$');
        insert into transaction_detail (transId, productId, quantity, price)
            value (new_bill_id, @product_id, @quantity, @price);
        set _index = _index + 1;
        end while;

    if _rollback = 1 then
        rollback;
        select true as err, 'transaction failed' as message;
    else
        commit;
        select false as err, 'transaction success' as message;
    end if;
end;

