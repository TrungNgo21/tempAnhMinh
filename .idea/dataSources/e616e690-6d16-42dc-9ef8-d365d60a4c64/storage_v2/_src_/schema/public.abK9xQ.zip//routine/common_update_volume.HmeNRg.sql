create
    definer = root@localhost procedure common_update_volume(IN warehouse_id bigint)
begin
    update warehouse
    set fillVolume =
        (
            select
                sum(w.ivolume) as wvolume
            from (
                select
                    (p.volume*wi.quantity) as ivolume
                from warehouse_inventory wi
                    join product p on wi.productID = p.id
                where warehouseID = warehouse_id
                group by wi.id, warehouseID) w
        )
        where ID = warehouse_id;
end;

