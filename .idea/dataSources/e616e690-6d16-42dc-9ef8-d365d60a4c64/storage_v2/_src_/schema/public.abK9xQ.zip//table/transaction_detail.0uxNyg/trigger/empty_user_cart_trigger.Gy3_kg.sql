create definer = root@localhost trigger empty_user_cart_trigger
    after insert
    on transaction_detail
    for each row
begin
        select userId into @user from transaction where id = new.transId;
        delete from user_cart where userId = @user and productId = new.productId;
    end;

